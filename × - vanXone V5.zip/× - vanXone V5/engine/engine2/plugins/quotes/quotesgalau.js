/**
 * Creator : × - vanXone </>
 * 
 * note : don't claim this code
 */

import sharp from 'sharp'
import { prepareWAMessageMedia } from '@whiskeysockets/baileys'

const URL = 'https://github.com/hamm-r'
const THUMB_URL = "https://raw.githubusercontent.com/hamm-r/uploader/main/1783126493162-298.jpg"

let handler = async (m, { conn, sock }) => {
    const list = [
    "Gak salah kalo aku lebih berharap sama orang yang lebih pasti tanpa khianati janji-janji.",
    "Kalau aku memang tidak sayang sama kamu ngapain aku mikirin kamu. Tapi semuanya kamu yang ngganggap aku gak sayang sama kamu.",
    "Mungkin kamu tak pernah sadar, betapa seringnya aku menatap layar hanya untuk menunggu satu pesan darimu.",
    "Hal paling menyakitkan adalah berpura-pura bahagia ketika hati sedang hancur lebur.",
    "Aku lelah mengejar seseorang yang langkahnya selalu menjauh dari arahku.",
    "Terkadang, melepaskan bukan berarti berhenti mencintai, melainkan menyadari bahwa dia lebih bahagia tanpamu.",
    "Kita pernah sedekat nadi, sebelum akhirnya menjadi sejauh matahari.",
    "Bagian terberat dari perpisahan bukanlah kepergiannya, tapi kenangan yang tertinggal di setiap sudut ingatan.",
    "Aku rindu kita yang dulu, sebelum rasa ego dan keheningan menghancurkan segalanya.",
    "Tersenyum di depan semua orang itu mudah, yang sulit adalah menahan air mata saat sendirian di kamar.",
    "Mungkin aku yang terlalu berharap pada seseorang yang hanya menganggapku persinggahan sementara.",
    "Sudah terbiasa diabaikan, sampai-sampai perhatian kecil terasa seperti keajaiban.",
    "Bukan jarak yang memisahkan kita, melainkan rasa yang perlahan memudar tanpa kita sadari.",
    "Menunggu kabar darimu seperti menunggu hujan di tengah teriknya gurun pasir.",
    "Ternyata, rasa sakit terdalam berasal dari orang yang pernah berjanji tidak akan pernah melukai kita.",
    "Aku tetap bertahan bukan karena bodoh, tapi karena hatiku belum siap menerima kenyataan bahwa kamu sudah pergi.",
    "Kehilangan seseorang yang kita cintai itu berat, tapi kehilangan diri sendiri demi mempertahankan seseorang jauh lebih menyakitkan.",
    "Hati ini seperti cangkir retak; tetap bisa menampung air, tapi perlahan-lahan menetes habis.",
    "Selamat malam untuk kamu yang tak lagi bisa kusapa, semoga mimpimu selalu indah meski tanpaku.",
    "Terima kasih telah mengajarkanku bahwa tidak semua ketulusan akan berbuah kebersamaan.",
    "Rasanya aneh ketika seseorang yang dulu tahu segalanya tentangmu kini bertingkah seperti orang asing.",
    "Luka ini tak berdarah, tapi rasa perihnya menembus hingga ke dasar jiwa.",
    "Aku berhenti mencarimu, bukan karena tak peduli, tapi karena sadar kehadiranku tak lagi dinanti.",
    "Mencintai dalam diam itu menyakitkan, tapi melihatnya mencintai orang lain di depan mata jauh lebih menghancurkan.",
    "Waktu memang menyembuhkan, tapi bekas lukanya tetap mengingatkan pada rasa sakit yang pernah ada."
]

    const quote = list[Math.floor(Math.random() * list.length)]
    const client = conn || sock
    const thumb = await getThumbUrl(THUMB_URL)
    const highQualityThumbnail = await createHighQualityThumbnail(client, thumb)
    const invisible = '\u200B'.repeat(400)
    const caption = `乂  *Q U O T E S  G A L A U*\n\n"${quote}"`

    await client.sendMessage(
        m.chat,
        {
            text: `${URL}${invisible}\n\n${caption}`,
            linkPreview: {
                'matched-text': URL,
                matchedText: URL,
                canonicalUrl: URL,
                title: "「 𝐐𝐔𝐎𝐓𝐄𝐒 𝐆𝐀𝐋𝐀𝐔 」",
                description: "Ungkapan Hati & Rasa Kecewa",
                previewType: 0,
                jpegThumbnail: thumb,
                highQualityThumbnail,
                thumbnailUrl: THUMB_URL,
                linkPreviewMetadata: {
                    linkMediaDuration: 0,
                    socialMediaPostType: 4
                }
            },
            favicon: {
                url: THUMB_URL
            }
        },
        { quoted: global.fmeta || m }
    )
}

handler.help = ["quotesgalau"]
handler.tags = ["quotes"]
handler.command = /^(quotesgalau|galau)$/i
handler.register = true
handler.limit = true

export default handler

let cachedThumb = null
async function getThumbUrl(url) {
  if (cachedThumb) return cachedThumb
  try {
    const res = await fetch(url)
    const raw = Buffer.from(await res.arrayBuffer())

    cachedThumb = await sharp(raw)
      .resize(1280, 720, {
        fit: 'cover',
        position: 'center'
      })
      .jpeg({ quality: 90 })
      .toBuffer()
    return cachedThumb
  } catch {
    return Buffer.alloc(0)
  }
}

async function createHighQualityThumbnail(conn, thumb) {
  try {
    if (!thumb || !thumb.length) return null

    const { imageMessage } = await prepareWAMessageMedia(
      { image: thumb },
      {
        upload: conn.waUploadToServer,
        mediaTypeOverride: 'thumbnail-link'
      }
    )

    imageMessage.width = 1280
    imageMessage.height = 720

    return imageMessage
  } catch {
    return null
  }
}

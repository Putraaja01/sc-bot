/**
 * Creator : × - vanXone </>
 * 
 * note : don't claim this code
 */

let handler = async (m, { conn, sock, reply }) => {
	const client = conn || sock
	const doReply = typeof reply === 'function' ? reply : typeof m.reply === 'function' ? m.reply.bind(m) : (txt) => client.sendMessage(m.chat, { text: txt }, { quoted: m })

	try {
		if (typeof global.react === 'function') {
			await global.react(client, m, 'loading')
		} else if (client.sendMessage) {
			await client.sendMessage(m.chat, { react: { text: '⏳', key: m.key } }).catch(() => {})
		}

		const url = global.API('kyzz', '/api/cecan/Indonesia', {}, 'apikey')
		await client.sendMessage(m.chat, {
			image: { url },
			caption: `🎴 Cewe Random — Indonesia`
		}, { quoted: m })

		if (typeof global.react === 'function') {
			await global.react(client, m, 'success')
		} else if (client.sendMessage) {
			await client.sendMessage(m.chat, { react: { text: '✅', key: m.key } }).catch(() => {})
		}
	} catch (e) {
		console.error('[CEWERANDOM:Indonesia]', e.response?.data || e)
		if (typeof global.react === 'function') {
			await global.react(client, m, 'error')
		} else if (client.sendMessage) {
			await client.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {})
		}
		doReply('❌ Gagal ambil gambar Indonesia.')
	}
}

handler.help = ["indonesia","ceweindo"]
handler.tags = ['cewerandom']
handler.command = /^(indonesia|ceweindo|cecanindo|ceceindo)$/i
handler.limit = true
handler.register = true

export default handler

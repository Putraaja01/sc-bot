// name   : YouTube scraper (search & direct url)
// base   : https://save-tube.com/ (+ QByte fallback)
// note   : taruh di lib/scrape/YouTube.js (sesuaikan sama struktur folder kamu)
// dipakai oleh plugin ytplay.js

const crypto = require('crypto')
const axios = require('axios')
const qs = require('qs')

class SaveTube {
    constructor() {
        this.ky = 'C5D58EF67A7584E4A29F6C35BBC4EB12'
        this.fmt = ['144', '240', '360', '480', '720', '1080', 'mp3']
        this.re =
            /^((?:https?:)?\/\/)?((?:www|m|music)\.)?(?:youtube\.com|youtu\.be)\/(?:watch\?v=)?(?:embed\/)?(?:v\/)?(?:shorts\/)?([a-zA-Z0-9_-]{11})/
        this.ua =
            'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36'
        this.maxTry = 4
    }

    decode(enc) {
        const data = Buffer.from(enc, 'base64')
        const iv = data.slice(0, 16)
        const ct = data.slice(16)
        const key = Buffer.from(this.ky, 'hex')
        const dc = crypto.createDecipheriv('aes-128-cbc', key, iv)
        return JSON.parse(Buffer.concat([dc.update(ct), dc.final()]).toString())
    }

    async getCdn() {
        const res = await axios.get('https://media.savetube.vip/api/random-cdn', { timeout: 10000 })
        return res.data.cdn
    }

    async sleep(ms) {
        return new Promise(r => setTimeout(r, ms))
    }

    cleanTitle(raw = '') {
        let t = String(raw)
        const lp =
            /lyrics?|official\s*(music\s*)?video|audio|visualizer|mv|m\/v|hd|4k|8k|full\s*song|original\s*mix|remaster(ed)?|live|cover|clean|explicit|extended|radio\s*edit|slowed|reverb|sped\s*up|color\s*coded|sub\s*indo|terjemahan|lyric\s*video/i
        t = t.replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{2190}-\u{21FF}\u{2B00}-\u{2BFF}\u{FE0F}\u{200D}]/gu, '')
        t = t.replace(/[\(\[\{][^\)\]\}]*[\)\]\}]/g, m => (lp.test(m) ? '' : m))
        t = t
            .replace(/\/\/+/g, ' - ')
            .replace(/[|:]{1,2}/g, ' ')
            .replace(/[#@]\S+/g, '')
        t = t.replace(new RegExp(`\\b(${lp.source})\\b`, 'gi'), '')
        t = t
            .replace(/\s{2,}/g, ' ')
            .replace(/\s+-\s*$/g, '')
            .replace(/^\s*-\s+/g, '')
            .trim()
        return t || String(raw).trim()
    }

    async download(url, format = 'mp3') {
        const id = url.match(this.re)?.[3]
        if (!id) throw new Error('ID tidak bisa diambil dari URL')
        if (!this.fmt.includes(format)) throw new Error(`Format tidak valid. Pilihan: ${this.fmt.join(', ')}`)
        let lastErr = null
        for (let attempt = 1; attempt <= this.maxTry; attempt++) {
            try {
                const cdn = await this.getCdn()
                const infoRes = await axios.post(
                    `https://${cdn}/v2/info`,
                    { url: `https://www.youtube.com/watch?v=${id}` },
                    { timeout: 15000, headers: { 'User-Agent': this.ua, Referer: 'https://save-tube.com/' } }
                )
                const info = this.decode(infoRes.data.data)
                const dlRes = await axios.post(
                    `https://${cdn}/download`,
                    {
                        downloadType: format === 'mp3' ? 'audio' : 'video',
                        quality: format === 'mp3' ? '128' : format,
                        key: info.key
                    },
                    {
                        timeout: 30000,
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Agent': this.ua,
                            Referer: 'https://save-tube.com/'
                        }
                    }
                )
                const dlUrl = dlRes.data?.data?.downloadUrl
                if (!dlUrl) throw new Error('downloadUrl tidak ditemukan')
                return {
                    title: this.cleanTitle(info.title),
                    rawTitle: info.title,
                    thumb: info.thumbnail || `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
                    duration: info.duration,
                    format,
                    url: dlUrl
                }
            } catch (e) {
                lastErr = e
                if (attempt < this.maxTry) await this.sleep(800 * attempt)
            }
        }
        throw new Error(`SaveTube gagal: ${lastErr?.message}`)
    }
}

class QByte {
    constructor() {
        this.api = 'https://be-video-downloader.qbyte.web.id'
        this.web = 'https://video.downloader.qbyte.web.id/'
        this.ua =
            'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36'
        this.http = axios.create({ timeout: 120000, maxRedirects: 5, validateStatus: () => true })
    }

    cleanName(t) {
        return String(t || 'media')
            .replace(/[\\/:*?"<>|]/g, '')
            .replace(/\s+/g, ' ')
            .trim()
    }

    getId(f) {
        return String(f.format_id || f.itag || f.id)
    }

    getHeight(f) {
        if (f.height) return Number(f.height)
        const r = String(f.resolution || '')
        const wxh = r.match(/(\d+)\s*x\s*(\d+)/i)
        if (wxh) return Number(wxh[2])
        const p = r.match(/(\d+)\s*p/i)
        if (p) return Number(p[1])
        const a = r.match(/\d+/)
        return a ? Number(a[0]) : 0
    }

    async download(url, format = 'mp3') {
        const headers = {
            'user-agent': this.ua,
            accept: 'application/json',
            origin: this.web.slice(0, -1),
            referer: this.web
        }
        const res = await this.http.get(`${this.api}/api/info`, { params: { url }, headers })
        if (res.status < 200 || res.status >= 300) throw new Error(`QByte info gagal HTTP ${res.status}`)
        const info = res.data
        const formats = Array.isArray(info.formats) ? info.formats : []

        const checkRes = await this.http.get(`${this.api}/api/check-download`, {
            headers: { 'user-agent': this.ua, accept: '*/*', referer: this.web }
        })
        if (checkRes.status < 200 || checkRes.status >= 300)
            throw new Error(`Server QByte penuh HTTP ${checkRes.status}`)

        const title = this.cleanName(info.title || 'media')

        if (format === 'mp3') {
            const audioFormat = formats
                .filter(f => f.vcodec === 'none' && f.acodec !== 'none')
                .sort((a, b) => Number(b.abr || b.tbr || 0) - Number(a.abr || a.tbr || 0))[0]
            if (!audioFormat) throw new Error('Format audio tidak ditemukan')
            const audioId = this.getId(audioFormat)
            const audioExt = audioFormat.ext || 'm4a'
            const dRes = await this.http.get(`${this.api}/api/download`, {
                params: { url, format: audioId, filename: `${title}.${audioExt}` },
                responseType: 'stream',
                headers: { 'user-agent': this.ua, accept: '*/*', referer: this.web }
            })
            if (dRes.status < 200 || dRes.status >= 300) throw new Error(`QByte audio gagal HTTP ${dRes.status}`)
            const chunks = []
            await new Promise((resolve, reject) => {
                dRes.data.on('data', c => chunks.push(c))
                dRes.data.on('end', resolve)
                dRes.data.on('error', reject)
            })
            return {
                title,
                thumb: `https://i.ytimg.com/vi/${url.match(/v=([^&]+)/)?.[1]}/hqdefault.jpg`,
                buffer: Buffer.concat(chunks),
                format: 'mp3'
            }
        }

        const target = parseInt(format) || 720
        const videoFormat =
            formats
                .filter(f => f.vcodec !== 'none' && this.getHeight(f) === target)
                .sort(
                    (a, b) =>
                        (String(b.ext).toLowerCase() === 'mp4' ? 1 : 0) -
                        (String(a.ext).toLowerCase() === 'mp4' ? 1 : 0)
                )[0] ??
            formats
                .filter(f => f.vcodec !== 'none')
                .sort((a, b) => Math.abs(this.getHeight(a) - target) - Math.abs(this.getHeight(b) - target))[0]
        if (!videoFormat) throw new Error('Format video tidak ditemukan')

        const audioFormat2 = formats
            .filter(f => f.vcodec === 'none' && f.acodec !== 'none')
            .sort((a, b) => Number(b.abr || b.tbr || 0) - Number(a.abr || a.tbr || 0))[0]

        const { spawn } = require('child_process')
        const fsp = require('fs/promises')
        const fs = require('fs')
        const path = require('path')
        const os = require('os')

        const tmpDir = os.tmpdir()
        const videoTmp = path.join(tmpDir, `qbyte-video-${Date.now()}.${videoFormat.ext || 'mp4'}`)
        const audioTmp = path.join(tmpDir, `qbyte-audio-${Date.now()}.${audioFormat2?.ext || 'm4a'}`)
        const outTmp = path.join(tmpDir, `qbyte-out-${Date.now()}.mp4`)

        const dlFile = async (formatId, filename, ext, outPath) => {
            const dRes = await this.http.get(`${this.api}/api/download`, {
                params: { url, format: formatId, filename },
                responseType: 'stream',
                headers: { 'user-agent': this.ua, accept: '*/*', referer: this.web }
            })
            if (dRes.status < 200 || dRes.status >= 300) throw new Error(`download gagal HTTP ${dRes.status}`)
            await new Promise((resolve, reject) => {
                const w = fs.createWriteStream(outPath)
                dRes.data.pipe(w)
                dRes.data.on('error', reject)
                w.on('finish', resolve)
                w.on('error', reject)
            })
        }

        await dlFile(this.getId(videoFormat), `${title}.${videoFormat.ext || 'mp4'}`, videoFormat.ext, videoTmp)
        if (audioFormat2)
            await dlFile(this.getId(audioFormat2), `${title}.${audioFormat2.ext || 'm4a'}`, audioFormat2.ext, audioTmp)

        const runFfmpeg = args =>
            new Promise((resolve, reject) => {
                const ff = spawn('ffmpeg', args, { stdio: ['ignore', 'ignore', 'pipe'] })
                let err = ''
                ff.stderr.on('data', c => (err += c.toString()))
                ff.on('close', code =>
                    code === 0 ? resolve() : reject(new Error(`FFmpeg gagal: ${err.slice(-500)}`))
                )
                ff.on('error', reject)
            })

        if (audioFormat2) {
            await runFfmpeg(['-y', '-i', videoTmp, '-i', audioTmp, '-c:v', 'copy', '-c:a', 'aac', '-shortest', outTmp])
        } else {
            await runFfmpeg(['-y', '-i', videoTmp, '-c:v', 'copy', outTmp])
        }

        const buffer = await fsp.readFile(outTmp)
        await fsp.unlink(videoTmp).catch(() => {})
        await fsp.unlink(audioTmp).catch(() => {})
        await fsp.unlink(outTmp).catch(() => {})

        return {
            title,
            thumb: `https://i.ytimg.com/vi/${url.match(/v=([^&]+)/)?.[1]}/hqdefault.jpg`,
            buffer,
            format: 'mp4'
        }
    }
}

const st = new SaveTube()
const qbyte = new QByte()

const innertubeKey = 'AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8'
const innertubeUa =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'

function findVideoRenderer(node, out) {
    if (!node || typeof node !== 'object') return
    if (node.videoRenderer?.videoId) {
        out.push(node.videoRenderer)
        return
    }
    for (const key in node) findVideoRenderer(node[key], out)
}

async function searchYoutube(q) {
    if (/^((?:https?:)?\/\/)?((?:www|m|music)\.)?(?:youtube\.com|youtu\.be)\//.test(q)) return q
    const res = await fetch(`https://www.youtube.com/youtubei/v1/search?key=${innertubeKey}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'User-Agent': innertubeUa,
            'X-Youtube-Client-Name': '1',
            'X-Youtube-Client-Version': '2.20240101.00.00'
        },
        body: JSON.stringify({
            context: { client: { clientName: 'WEB', clientVersion: '2.20240101.00.00', hl: 'en', gl: 'US' } },
            query: q
        }),
        signal: AbortSignal.timeout(15000)
    })
    if (!res.ok) throw new Error(`Pencarian gagal HTTP ${res.status}`)
    const json = await res.json()
    const found = []
    findVideoRenderer(json.contents, found)
    if (!found.length) throw new Error('video tidak ditemukan')
    return `https://www.youtube.com/watch?v=${found[0].videoId}`
}

async function toBuffer(url, retries = 3) {
    let lastErr = null
    for (let i = 0; i < retries; i++) {
        try {
            const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 60000 })
            return Buffer.from(res.data)
        } catch (e) {
            lastErr = e
            if (i < retries - 1) await new Promise(r => setTimeout(r, 800 * (i + 1)))
        }
    }
    throw lastErr
}

async function remuxVideoBuffer(buf) {
    const { execFile } = require('child_process')
    const { promisify } = require('util')
    const fs = require('fs/promises')
    const os = require('os')
    const path = require('path')
    const { randomUUID } = require('crypto')
    const execFileAsync = promisify(execFile)
    const inPath = path.join(os.tmpdir(), `yt_in_${randomUUID()}.mp4`)
    const outPath = path.join(os.tmpdir(), `yt_out_${randomUUID()}.mp4`)
    try {
        await fs.writeFile(inPath, buf)
        const { stdout } = await execFileAsync('ffprobe', [
            '-v', 'error', '-print_format', 'json', '-show_format', '-show_streams', inPath
        ])
        const data = JSON.parse(stdout)
        const duration = parseFloat(data?.format?.duration || '0')
        const hasAudio = (data?.streams || []).some(s => s.codec_type === 'audio')
        const args = ['-y', '-i', inPath, '-map', '0:v:0']
        if (hasAudio) args.push('-map', '0:a:0?')
        args.push('-c:v', 'copy', '-c:a', 'copy')
        if (duration > 0) args.push('-t', duration.toString())
        args.push('-avoid_negative_ts', 'make_zero', '-movflags', '+faststart', outPath)
        await execFileAsync('ffmpeg', args)
        return await fs.readFile(outPath)
    } catch {
        return buf
    } finally {
        await fs.unlink(inPath).catch(() => {})
        await fs.unlink(outPath).catch(() => {})
    }
}

async function getYoutubeDirectUrl(url, format = '360') {
    const formats = [format, '480', '720', '240', '144'].filter((v, i, a) => a.indexOf(v) === i)
    let lastError = null
    for (const fmt of formats) {
        try {
            const res = await st.download(url, fmt)
            if (res?.url) return res
        } catch (e) {
            lastError = e
        }
    }
    throw lastError || new Error('Gagal mendapatkan link download video')
}

async function downloadWithFallback(url, format) {
    try {
        return await st.download(url, format)
    } catch (e1) {
        console.warn(`[SaveTube] gagal: ${e1.message}, fallback ke QByte`)
        const res = await qbyte.download(url, format)
        return { ...res, url: null, _buffer: res.buffer }
    }
}

// ============================================================
// tambahan: ssyoutube scraper (dari kamu, gak diubah/diganti)
// ============================================================

const SS_CONFIG = {
    BASE_URL: "https://ssyoutube.com",
    API: {
        CONVERT: "/api/convert"
    },
    SECRETS: {
        SALT: "384d5028ee4a399f6cae0175025a1708aa924fc0ccb08be1aa359cd856dd1639",
        FIXED_TS: "1765962059039"
    },
    HEADERS: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "application/json, text/plain, */*",
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
        "Origin": "https://ssyoutube.com",
        "Referer": "https://ssyoutube.com/"
    }
};

const ssCryptoUtils = () => {
    return {
        generateSignature: (url, timestamp) => {
            try {
                const rawString = url + timestamp + SS_CONFIG.SECRETS.SALT;
                return crypto.createHash('sha256').update(rawString).digest('hex');
            } catch (e) {
                console.error("Error generating signature:", e);
                return null;
            }
        }
    };
};

const ssUtils = ssCryptoUtils();

const ssFormatSize = (bytes) => {
    if (!bytes) return 'Unknown';
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return parseFloat((bytes / Math.pow(1024, i)).toFixed(2)) + ' ' + sizes[i];
};

const ssyoutube = {
    download: async (videoUrl) => {
        try {
            if (!videoUrl || !videoUrl.includes('youtube.com') && !videoUrl.includes('youtu.be')) {
                return { error: 'URL tidak valid. Harap gunakan URL YouTube.' };
            }

            const currentTs = Date.now().toString();
            const signature = ssUtils.generateSignature(videoUrl, currentTs);

            if (!signature) return { error: 'Gagal membuat signature keamanan.' };

            const payload = {
                'sf_url': videoUrl,
                'ts': currentTs,
                '_ts': SS_CONFIG.SECRETS.FIXED_TS,
                '_tsc': '0',
                '_s': signature
            };

            const response = await axios.post(
                SS_CONFIG.BASE_URL + SS_CONFIG.API.CONVERT,
                qs.stringify(payload), 
                { headers: SS_CONFIG.HEADERS }
            );

            const data = response.data;

            if (!data || !data.url) {
                return { error: 'Gagal mengambil data. Server mungkin memblokir request.' };
            }

            const result = {
                meta: {
                    id: data.id,
                    title: data.meta?.title,
                    duration: data.meta?.duration,
                    thumbnail: data.thumb
                },
                downloads: []
            };

            if (Array.isArray(data.url)) {
                result.downloads = data.url
                    .filter(item => !item.no_audio)
                    .map(item => ({
                        quality: item.quality || item.subname,
                        format: item.ext,
                        size: ssFormatSize(item.filesize),
                        url: item.url,
                        audio: item.audio
                    }));
            }

            return result;

        } catch (error) {
            console.error(`error download: ${error.message}`);
            if (error.response) console.error("Server Response:", error.response.data);
            return { error: error.message };
        }
    }
};

// SAMPLE RESPONSE
// {
//   meta: {
//     id: 'ZaHSqOzAvWs',
//     title: 'Add-on BoBoiBug Galaxy V3 (Ultimate bug update) -- MCPE Add-on',
//     duration: '4:50',
//     thumbnail: 'https://media.ssyoutube.com/get?...'
//   },
//   downloads: [
//     { quality: '720', format: 'mp4', size: 'Unknown', url: '...', audio: undefined },
//     { quality: '360', format: 'mp4', size: '24.26 MB', url: '...', audio: false },
//     { quality: '141', format: 'm4a', size: '4.47 MB', url: '...', audio: true }
//   ]
// }

module.exports = {
    searchYoutube,
    toBuffer,
    remuxVideoBuffer,
    getYoutubeDirectUrl,
    downloadWithFallback,
    ssyoutube
}
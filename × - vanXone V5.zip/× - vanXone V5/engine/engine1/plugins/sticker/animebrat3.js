const axios = require('axios')
const config = require('../../config')
const { f } = require('../../src/lib/undici')

const pluginConfig = {
    name: 'bratanime3',
    alias: ['animebrat3'],
    category: 'sticker',
    description: 'Membuat sticker brat anime versi 3',
    usage: '.animebrat3 <text>',
    example: '.animebrat3 × - vanXone </>',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 1,
    isEnabled: true
}

async function handler(m, { sock }) {
    const text = m.args.join(' ')

    if (!text) {
        return m.reply(
            `🖼️ *ʙʀᴀᴛ ᴀɴɪᴍᴇ sᴛɪᴄᴋᴇʀ v3*\n\n` +
            `> Masukkan teks\n\n` +
            `\`Contoh: ${m.prefix}animebrat3 × - vanXone </>\``
        )
    }

    m.react('🕕')

    try {
        const url = `https://api.theresav.biz.id/maker/bratanime2?text=${encodeURIComponent(text)}&apikey=${(global.apiKeys && global.apiKeys.theresav) || ''}`

        await sock.sendImageAsSticker(
            m.chat,
            url,
            m,
            {
                packname: config.sticker.packname,
                author: config.sticker.author
            }
        )

        m.react('✅')
    } catch (error) {
        console.error(error)

        m.react('❌')
        m.reply(
            `❌ *ᴇʀʀᴏʀ*\n\n` +
            `> ${error.message}`
        )
    }
}

module.exports = {
    config: pluginConfig,
    handler
}